# Gets root privileges
echo Requires your password.
sudo su

# Installs dependencies
apt-get install -y libav-tools
pip3 install pydub

# Installs program.
mv raspbian-music /usr/local/bin
#mv raspbian-music.desktop /usr/share/applications

# Prints confirmation
echo
echo Successfully installed raspbian music!
echo No desktop shortcut yet. Sorry! Execute by typing raspbian-music...
